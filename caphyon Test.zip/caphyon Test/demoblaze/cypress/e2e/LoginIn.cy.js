describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://www.demoblaze.com/')
    cy.wait(1500)
    cy.get('#login2').click()
    cy.wait(1500)
    cy.get('#loginusername').type('stanciuadrian151')
    cy.wait(1500)
    cy.get('#loginpassword').type('Password')
    cy.wait(1500)
    cy.get('button[onclick="logIn()"]').click()
  })
})