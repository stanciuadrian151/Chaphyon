describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://www.demoblaze.com/')
    cy.wait(1500)
    cy.get('#signin2').click()
    cy.wait(1500)
    cy.get('#sign-username').type('stanciuadrian151')
    cy.wait(1500)
    cy.get('#sign-password').type('Password')
    cy.wait(1500)
    cy.get('button[onclick="register()"]').click()
  })
})