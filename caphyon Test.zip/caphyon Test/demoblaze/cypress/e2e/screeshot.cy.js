describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://www.demoblaze.com/')
    cy.wait(1500)
    cy.screenshot('HomePage')
  })
})