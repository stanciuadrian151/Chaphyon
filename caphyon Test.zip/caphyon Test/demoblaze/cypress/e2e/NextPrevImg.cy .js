describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://www.demoblaze.com/')
    cy.wait(1500)
    cy.get('.carousel-control-next-icon').click()
    cy.wait(1500)
    cy.get('.carousel-control-prev-icon').click()
  })
})