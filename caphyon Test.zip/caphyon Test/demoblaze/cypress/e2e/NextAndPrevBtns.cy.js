describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://www.demoblaze.com/')
    cy.wait(1500)
    cy.get('#next2').click()
    cy.wait(1500)
    cy.get('#prev2').click()
  })
})